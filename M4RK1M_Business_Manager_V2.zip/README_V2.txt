M4RK1M BUSINESS MANAGER V2
Dark Premium · Dark Gray + Blue · Offline-first · PHP

V2 features:
- Dashboard for daily sales, expenses, estimated profit, inventory and outstanding utang
- Multi-product inventory with flexible units
- Product selling prices auto-fill on the sales screen
- Individual sales deduct stock; daily-total sales do not
- Stock-in and purchase history
- Expense records and history
- Utang per customer, partial payments, remaining balance and payment history
- CSV export for sales, purchases, expenses, utang and payments
- JSON backup and restore using Android's native file picker/save dialog
- Two-step confirmation before deleting all records

V1 DATA PRESERVATION:
- V2 first checks the V2 storage key, then migrates existing records from the V1 key
  `markimBizV1` when no V2 data exists.
- V2 continues writing the compatible business data to the V1 key as well as V2 storage.
- Do not uninstall V1, clear app storage, or overwrite your only copy before making and
  checking a backup.
- Android updates require the same application ID AND signing certificate. If Android
  refuses an in-place update because of a signature mismatch, do not uninstall V1 until
  its data has been exported or otherwise safely recovered.

BUILD:
- GitHub Actions workflow: `.github/workflows/android.yml`
- Workflow downloads Gradle 8.9, uses Java 17, and builds `assembleDebug`.
- Artifact name: `M4RK1M-Business-Manager-V2-debug`
- APK path: `app/build/outputs/apk/debug/app-debug.apk`

IMPORTANT:
- App data is stored locally on this device; no cloud sync is included.
- JSON backup and CSV export use Android's document picker through the native bridge.
- This source ZIP has not yet been built on an Android/Gradle runner in this session.
