package com.markim.businessmanager;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 4101;
    private static final int OPEN_FILE = 4102;
    private WebView webView;
    private byte[] pendingBytes;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String content, String fileName, String mimeType) {
            runOnUiThread(() -> {
                try {
                    pendingBytes = content.getBytes(StandardCharsets.UTF_8);
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType == null ? "application/octet-stream" : mimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, fileName);
                    startActivityForResult(intent, CREATE_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Cannot open save dialog.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void chooseRestore() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream"});
                startActivityForResult(intent, OPEN_FILE);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBytes = null;
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == CREATE_FILE && pendingBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Unable to open destination");
                    out.write(pendingBytes);
                    out.flush();
                }
                pendingBytes = null;
                Toast.makeText(this, "File saved successfully.", Toast.LENGTH_LONG).show();
            } else if (requestCode == OPEN_FILE) {
                StringBuilder text = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new Exception("Unable to open selected file");
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) text.append(new String(buffer, 0, count, StandardCharsets.UTF_8));
                }
                String encoded = org.json.JSONObject.quote(text.toString());
                webView.evaluateJavascript("window.onNativeRestore(" + encoded + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "File operation failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            pendingBytes = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
