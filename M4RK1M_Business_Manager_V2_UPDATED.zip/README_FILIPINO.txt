M4RK1M BUSINESS MANAGER - ANDROID PROJECT
Prototype 0.1 | Dark theme | PHP | Offline-first

Features:
- Flexible product names and units (pcs, kg, bundle, etc.)
- Opening stock and stock-in / purchase records
- Individual sales deduct inventory automatically
- Daily total sales entry (does not deduct inventory)
- Expense records, dashboard and basic reports
- CSV export and JSON backup/restore
- Data stored locally on this device

Limitations:
- Early prototype, not formal accounting/tax software.
- No cloud sync, login, multi-device sharing, auto backup or barcode scanner.
- Daily-total sales do not change stock. Use individual sales for stock deduction.
- Export backups regularly; clearing app data/uninstalling may erase records.
- Profit figures are estimates and need careful review.

Build APK using only a phone (GitHub cloud build):
1. Sign in to GitHub in Chrome and create a new repository: markim-business-manager.
2. Upload ALL contents of this project ZIP into the repository, preserving folder paths.
3. Open Actions. Enable workflows if asked.
4. Select "Build Android APK" then tap "Run workflow".
5. Wait for a successful run. Open the run and download the artifact
   "M4RK1M-Business-Manager-debug".
6. Extract that downloaded artifact ZIP and install app-debug.apk.
7. Android may ask permission to install unknown apps for Chrome or Files.
   Only install APKs built from your own repository.

Computer build:
Requires Android SDK 35 and JDK 17. Run `gradle assembleDebug`.
APK: app/build/outputs/apk/debug/app-debug.apk

The Android wrapper loads the offline HTML app bundled inside the APK.
